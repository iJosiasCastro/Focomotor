export const SsrCarousel = () => import('../..\\node_modules\\vue-ssr-carousel\\index.js' /* webpackChunkName: "components/ssr-carousel" */).then(c => wrapFunctional(c.default || c))
export const App = () => import('../..\\components\\App.vue' /* webpackChunkName: "components/app" */).then(c => wrapFunctional(c.default || c))
export const PartialsAds = () => import('../..\\components\\Partials\\Ads.vue' /* webpackChunkName: "components/partials-ads" */).then(c => wrapFunctional(c.default || c))
export const PartialsFooter = () => import('../..\\components\\Partials\\Footer.vue' /* webpackChunkName: "components/partials-footer" */).then(c => wrapFunctional(c.default || c))
export const PartialsHeader = () => import('../..\\components\\Partials\\Header.vue' /* webpackChunkName: "components/partials-header" */).then(c => wrapFunctional(c.default || c))
export const PartialsImageUploader = () => import('../..\\components\\Partials\\ImageUploader.vue' /* webpackChunkName: "components/partials-image-uploader" */).then(c => wrapFunctional(c.default || c))
export const PartialsInfoModal = () => import('../..\\components\\Partials\\InfoModal.vue' /* webpackChunkName: "components/partials-info-modal" */).then(c => wrapFunctional(c.default || c))
export const PartialsModal = () => import('../..\\components\\Partials\\Modal.vue' /* webpackChunkName: "components/partials-modal" */).then(c => wrapFunctional(c.default || c))
export const PartialsSubtitle = () => import('../..\\components\\Partials\\Subtitle.vue' /* webpackChunkName: "components/partials-subtitle" */).then(c => wrapFunctional(c.default || c))
export const PartialsTitle = () => import('../..\\components\\Partials\\Title.vue' /* webpackChunkName: "components/partials-title" */).then(c => wrapFunctional(c.default || c))
export const UserEmailLogin = () => import('../..\\components\\User\\EmailLogin.vue' /* webpackChunkName: "components/user-email-login" */).then(c => wrapFunctional(c.default || c))
export const UserForm = () => import('../..\\components\\User\\Form.vue' /* webpackChunkName: "components/user-form" */).then(c => wrapFunctional(c.default || c))
export const UserLogin = () => import('../..\\components\\User\\Login.vue' /* webpackChunkName: "components/user-login" */).then(c => wrapFunctional(c.default || c))
export const VehicleBuyPlans = () => import('../..\\components\\Vehicle\\BuyPlans.vue' /* webpackChunkName: "components/vehicle-buy-plans" */).then(c => wrapFunctional(c.default || c))
export const VehicleCard = () => import('../..\\components\\Vehicle\\Card.vue' /* webpackChunkName: "components/vehicle-card" */).then(c => wrapFunctional(c.default || c))
export const VehicleForm = () => import('../..\\components\\Vehicle\\Form.vue' /* webpackChunkName: "components/vehicle-form" */).then(c => wrapFunctional(c.default || c))
export const PartialsFormInput = () => import('../..\\components\\Partials\\Form\\Input.vue' /* webpackChunkName: "components/partials-form-input" */).then(c => wrapFunctional(c.default || c))
export const PartialsHomeConcessionairePromotion = () => import('../..\\components\\Partials\\Home\\ConcessionairePromotion.vue' /* webpackChunkName: "components/partials-home-concessionaire-promotion" */).then(c => wrapFunctional(c.default || c))
export const PartialsHomePopularBrands = () => import('../..\\components\\Partials\\Home\\PopularBrands.vue' /* webpackChunkName: "components/partials-home-popular-brands" */).then(c => wrapFunctional(c.default || c))
export const PartialsHomeSearchMenu = () => import('../..\\components\\Partials\\Home\\searchMenu.vue' /* webpackChunkName: "components/partials-home-search-menu" */).then(c => wrapFunctional(c.default || c))
export const VehicleIndexActiveFilters = () => import('../..\\components\\Vehicle\\index\\ActiveFilters.vue' /* webpackChunkName: "components/vehicle-index-active-filters" */).then(c => wrapFunctional(c.default || c))
export const VehicleIndexFilters = () => import('../..\\components\\Vehicle\\index\\Filters.vue' /* webpackChunkName: "components/vehicle-index-filters" */).then(c => wrapFunctional(c.default || c))
export const VehicleIndexPagination = () => import('../..\\components\\Vehicle\\index\\Pagination.vue' /* webpackChunkName: "components/vehicle-index-pagination" */).then(c => wrapFunctional(c.default || c))
export const VehicleShowGallery = () => import('../..\\components\\Vehicle\\show\\Gallery.vue' /* webpackChunkName: "components/vehicle-show-gallery" */).then(c => wrapFunctional(c.default || c))
export const VehicleShowMessageModal = () => import('../..\\components\\Vehicle\\show\\MessageModal.vue' /* webpackChunkName: "components/vehicle-show-message-modal" */).then(c => wrapFunctional(c.default || c))
export const VehicleIndexFilterBrands = () => import('../..\\components\\Vehicle\\index\\filter\\brands.vue' /* webpackChunkName: "components/vehicle-index-filter-brands" */).then(c => wrapFunctional(c.default || c))
export const VehicleIndexFilterCategories = () => import('../..\\components\\Vehicle\\index\\filter\\categories.vue' /* webpackChunkName: "components/vehicle-index-filter-categories" */).then(c => wrapFunctional(c.default || c))
export const VehicleIndexFilterCities = () => import('../..\\components\\Vehicle\\index\\filter\\Cities.vue' /* webpackChunkName: "components/vehicle-index-filter-cities" */).then(c => wrapFunctional(c.default || c))
export const VehicleIndexFilterFuels = () => import('../..\\components\\Vehicle\\index\\filter\\fuels.vue' /* webpackChunkName: "components/vehicle-index-filter-fuels" */).then(c => wrapFunctional(c.default || c))
export const VehicleIndexFilterMileage = () => import('../..\\components\\Vehicle\\index\\filter\\mileage.vue' /* webpackChunkName: "components/vehicle-index-filter-mileage" */).then(c => wrapFunctional(c.default || c))
export const VehicleIndexFilterMobileMenu = () => import('../..\\components\\Vehicle\\index\\filter\\mobileMenu.vue' /* webpackChunkName: "components/vehicle-index-filter-mobile-menu" */).then(c => wrapFunctional(c.default || c))
export const VehicleIndexFilterModels = () => import('../..\\components\\Vehicle\\index\\filter\\models.vue' /* webpackChunkName: "components/vehicle-index-filter-models" */).then(c => wrapFunctional(c.default || c))
export const VehicleIndexFilterOrderBy = () => import('../..\\components\\Vehicle\\index\\filter\\orderBy.vue' /* webpackChunkName: "components/vehicle-index-filter-order-by" */).then(c => wrapFunctional(c.default || c))
export const VehicleIndexFilterOrderByDropdown = () => import('../..\\components\\Vehicle\\index\\filter\\OrderByDropdown.vue' /* webpackChunkName: "components/vehicle-index-filter-order-by-dropdown" */).then(c => wrapFunctional(c.default || c))
export const VehicleIndexFilterPrice = () => import('../..\\components\\Vehicle\\index\\filter\\price.vue' /* webpackChunkName: "components/vehicle-index-filter-price" */).then(c => wrapFunctional(c.default || c))
export const VehicleIndexFilterState = () => import('../..\\components\\Vehicle\\index\\filter\\state.vue' /* webpackChunkName: "components/vehicle-index-filter-state" */).then(c => wrapFunctional(c.default || c))
export const VehicleIndexFilterYear = () => import('../..\\components\\Vehicle\\index\\filter\\year.vue' /* webpackChunkName: "components/vehicle-index-filter-year" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
