import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _46e0fc7d = () => interopDefault(import('..\\views\\home.vue' /* webpackChunkName: "" */))
const _1f721d78 = () => interopDefault(import('..\\views\\vehicle\\index.vue' /* webpackChunkName: "" */))
const _687e960a = () => interopDefault(import('..\\views\\vehicle\\show.vue' /* webpackChunkName: "" */))
const _404b81fa = () => interopDefault(import('..\\views\\vehicle\\create.vue' /* webpackChunkName: "" */))
const _d59bb9ee = () => interopDefault(import('..\\views\\vehicle\\author.vue' /* webpackChunkName: "" */))
const _7e409f8a = () => interopDefault(import('..\\views\\user\\dashboard.vue' /* webpackChunkName: "" */))
const _3f6ff988 = () => interopDefault(import('..\\views\\vehicle\\edit.vue' /* webpackChunkName: "" */))
const _71c12210 = () => interopDefault(import('..\\views\\user\\login.vue' /* webpackChunkName: "" */))
const _786bfccc = () => interopDefault(import('..\\views\\user\\register.vue' /* webpackChunkName: "" */))
const _76ea6133 = () => interopDefault(import('..\\views\\user\\edit.vue' /* webpackChunkName: "" */))
const _4cda0f9e = () => interopDefault(import('..\\views\\user\\resetPassword.vue' /* webpackChunkName: "" */))
const _d56c26d2 = () => interopDefault(import('..\\views\\user\\googleLogin.vue' /* webpackChunkName: "" */))
const _ec312f2a = () => interopDefault(import('..\\views\\info\\terms.vue' /* webpackChunkName: "" */))
const _525ee07e = () => interopDefault(import('..\\views\\info\\policy.vue' /* webpackChunkName: "" */))
const _7d788b84 = () => interopDefault(import('..\\views\\info\\contact.vue' /* webpackChunkName: "" */))
const _3e258e4a = () => interopDefault(import('..\\views\\plan\\index.vue' /* webpackChunkName: "" */))
const _bc10c2f8 = () => interopDefault(import('..\\views\\plan\\show.vue' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _46e0fc7d,
    name: "home"
  }, {
    path: "/listado",
    component: _1f721d78,
    name: "vehicle.index"
  }, {
    path: "/vehiculos/:slug",
    component: _687e960a,
    name: "vehicle.show"
  }, {
    path: "/publicar",
    component: _404b81fa,
    name: "vehicle.create"
  }, {
    path: "/autor/:slug",
    component: _d59bb9ee,
    name: "vehicle.author"
  }, {
    path: "/mis-vehiculos",
    component: _7e409f8a,
    name: "user.dashboard"
  }, {
    path: "/mis-vehiculos/editar/:slug",
    component: _3f6ff988,
    name: "vehicle.edit"
  }, {
    path: "/ingresar",
    component: _71c12210,
    name: "user.login"
  }, {
    path: "/registrarse",
    component: _786bfccc,
    name: "user.register"
  }, {
    path: "/usuario/editar",
    component: _76ea6133,
    name: "user.edit"
  }, {
    path: "/restablecer",
    component: _4cda0f9e,
    name: "user.resetPassword"
  }, {
    path: "/google-login",
    component: _d56c26d2,
    name: "google-login"
  }, {
    path: "/terminos-y-condiciones",
    component: _ec312f2a,
    name: "info.terms"
  }, {
    path: "/politica-de-privacidad",
    component: _525ee07e,
    name: "info.policy"
  }, {
    path: "/contacto",
    component: _7d788b84,
    name: "info.contact"
  }, {
    path: "/planes",
    component: _3e258e4a,
    name: "plan.index"
  }, {
    path: "/planes/:slug",
    component: _bc10c2f8,
    name: "plan.show"
  }, {
    path: "/vehiculos",
    redirect: "/listado"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
